# three.js + ribbons

A Pen created on CodePen.io. Original URL: [https://codepen.io/Chaya-Spencer/pen/MWNaWeg](https://codepen.io/Chaya-Spencer/pen/MWNaWeg).

